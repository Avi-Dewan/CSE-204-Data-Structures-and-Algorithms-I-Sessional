The main BST is in BST.cpp which is an implementation of Dictionary ADT. 

BSTNode.cpp describes the node of tree which is also an implementatin of BinNodeADT

main.cpp is where we used the BST to do some operation